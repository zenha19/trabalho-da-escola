public class Baralho {
String naipe="";
String valor="";
    public Baralho(String naipe, String valor)
    {
        this.naipe = naipe;
        this.valor= valor;

    }
    public static Baralho carta1 = new Baralho("copas","A");
    public static Baralho carta2 = new Baralho("copas","Q");
    public static Baralho carta3 = new Baralho("copas","K");
    public static Baralho carta4 = new Baralho("copas","J");
    public static Baralho carta5 = new Baralho("copas","1");
    public static Baralho carta6 = new Baralho("copas","2");
    public static Baralho carta7 = new Baralho("copas","3");
    public static Baralho carta8 = new Baralho("copas","4");
    public static Baralho carta9 = new Baralho("copas","6");
    public static Baralho carta10 = new Baralho("copas","7");
    public static Baralho carta11 = new Baralho("copas","8");
    public static Baralho carta12 = new Baralho("copas","9");
    public static Baralho carta13 = new Baralho("copas","10");
    public static Baralho carta14 = new Baralho("paus","A");
    public static Baralho carta15 = new Baralho("paus","Q");
    public static Baralho carta16 = new Baralho("paus","K");
    public static Baralho carta17 = new Baralho("paus","J");
    public static Baralho carta18 = new Baralho("paus","1");
    public static Baralho carta19 = new Baralho("paus","2");
    public static Baralho carta20 = new Baralho("paus","3");
    public static Baralho carta21 = new Baralho("paus","4");
    public static Baralho carta22 = new Baralho("paus","6");
    public static Baralho carta23 = new Baralho("paus","7");
    public static Baralho carta24 = new Baralho("paus","8");
    public static Baralho carta25 = new Baralho("paus","9");
    public static Baralho carta26 = new Baralho("paus","10");
    public static Baralho carta27 = new Baralho("ouros","A");
    public static Baralho carta28 = new Baralho("ouros","Q");
    public static Baralho carta29 = new Baralho("ouros","K");
    public static Baralho carta30 = new Baralho("ouros","J");
    public static Baralho carta31 = new Baralho("ouros","1");
    public static Baralho carta32 = new Baralho("ouros","2");
    public static Baralho carta33 = new Baralho("ouros","3");
    public static Baralho carta34 = new Baralho("ouros","4");
    public static Baralho carta35 = new Baralho("ouros","6");
    public static Baralho carta36 = new Baralho("ouros","7");
    public static Baralho carta37 = new Baralho("ouros","8");
    public static Baralho carta38 = new Baralho("ouros","9");
    public static Baralho carta39 = new Baralho("ouros","10");
    public static Baralho carta40 = new Baralho("espadas","A");
    public static Baralho carta41 = new Baralho("espadas","Q");
    public static Baralho carta42 = new Baralho("espadas","K");
    public static Baralho carta43 = new Baralho("espadas","J");
    public static Baralho carta44 = new Baralho("espadas","1");
    public static Baralho carta45 = new Baralho("espadas","2");
    public static Baralho carta46 = new Baralho("espadas","3");
    public static Baralho carta47 = new Baralho("espadas","4");
    public static Baralho carta48 = new Baralho("espadas","6");
    public static Baralho carta49 = new Baralho("espada","7");
    public static Baralho carta50 = new Baralho("espada","8");
    public static Baralho carta51 = new Baralho("espada","9");
    public static Baralho carta52 = new Baralho("espada","10");
}
