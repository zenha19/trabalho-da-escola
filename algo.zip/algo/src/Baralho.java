import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Baralho {
    String naipe="";
    String valor="";
    int id=0;

    public static List <Baralho> cardslist = new ArrayList<>(){};
    public Baralho(int id, String naipe, String valor)
    {
        this.id=id;
        this.naipe = naipe;
        this.valor= valor;
        cardslist.add(this);
    }


    public static Baralho carta1 = new Baralho(0,"copas","A");
    public static Baralho carta2 = new Baralho(1,"copas","Q");
    public static Baralho carta3 = new Baralho(2,"copas","K");
    public static Baralho carta4 = new Baralho(3,"copas","J");
    public static Baralho carta5 = new Baralho(4,"copas","1");
    public static Baralho carta6 = new Baralho(5,"copas","2");
    public static Baralho carta7 = new Baralho(6,"copas","3");
    public static Baralho carta8 = new Baralho(7,"copas","4");
    public static Baralho carta9 = new Baralho(8,"copas","6");
    public static Baralho carta10 = new Baralho(9,"copas","7");
    public static Baralho carta11 = new Baralho(10,"copas","8");
    public static Baralho carta12 = new Baralho(11,"copas","9");
    public static Baralho carta13 = new Baralho(12,"copas","10");
    public static Baralho carta14 = new Baralho(13,"paus","A");
    public static Baralho carta15 = new Baralho(14,"paus","Q");
    public static Baralho carta16 = new Baralho(15,"paus","K");
    public static Baralho carta17 = new Baralho(16,"paus","J");
    public static Baralho carta18 = new Baralho(17,"paus","1");
    public static Baralho carta19 = new Baralho(18,"paus","2");
    public static Baralho carta20 = new Baralho(19,"paus","3");
    public static Baralho carta21 = new Baralho(20,"paus","4");
    public static Baralho carta22 = new Baralho(21,"paus","6");
    public static Baralho carta23 = new Baralho(22,"paus","7");
    public static Baralho carta24 = new Baralho(23,"paus","8");
    public static Baralho carta25 = new Baralho(24,"paus","9");
    public static Baralho carta26 = new Baralho(25,"paus","10");
    public static Baralho carta27 = new Baralho(26,"ouros","A");
    public static Baralho carta28 = new Baralho(27,"ouros","Q");
    public static Baralho carta29 = new Baralho(28,"ouros","K");
    public static Baralho carta30 = new Baralho(29,"ouros","J");
    public static Baralho carta31 = new Baralho(30,"ouros","1");
    public static Baralho carta32 = new Baralho(31,"ouros","2");
    public static Baralho carta33 = new Baralho(32,"ouros","3");
    public static Baralho carta34 = new Baralho(33,"ouros","4");
    public static Baralho carta35 = new Baralho(34,"ouros","6");
    public static Baralho carta36 = new Baralho(35,"ouros","7");
    public static Baralho carta37 = new Baralho(36,"ouros","8");
    public static Baralho carta38 = new Baralho(37,"ouros","9");
    public static Baralho carta39 = new Baralho(38,"ouros","10");
    public static Baralho carta40 = new Baralho(39,"espadas","A");
    public static Baralho carta41 = new Baralho(40,"espadas","Q");
    public static Baralho carta42 = new Baralho(41,"espadas","K");
    public static Baralho carta43 = new Baralho(42,"espadas","J");
    public static Baralho carta44 = new Baralho(43,"espadas","1");
    public static Baralho carta45 = new Baralho(44,"espadas","2");
    public static Baralho carta46 = new Baralho(45,"espadas","3");
    public static Baralho carta47 = new Baralho(46,"espadas","4");
    public static Baralho carta48 = new Baralho(47,"espadas","6");
    public static Baralho carta49 = new Baralho(48,"espada","7");
    public static Baralho carta50 = new Baralho(49,"espada","8");
    public static Baralho carta51 = new Baralho(50,"espada","9");
    public static Baralho carta52 = new Baralho(51,"espada","10");


}
