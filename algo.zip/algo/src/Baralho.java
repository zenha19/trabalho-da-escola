public class Baralho {
String naipe="";
String valor="";
    public Baralho(String naipe, String valor)
    {
        this.naipe = naipe;
        this.valor= valor;

    }
    public static Baralho carta1 = new Baralho("coração","A");
}
