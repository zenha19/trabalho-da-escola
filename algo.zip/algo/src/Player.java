import java.util.ArrayList;
import java.util.List;

public class Player {
String name="";
Player jogador1=new Player();
Player jogador2=new Player();

    public void player(String name)
    {
        this.name = name;
    }

    public static List<Player>JogadorBaralho =new ArrayList<>()
    {

    };
    public Player()
    {
        JogadorBaralho = new ArrayList<>();
    }
}
