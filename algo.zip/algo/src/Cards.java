import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class Cards {


    static List <Cards> baralho =new ArrayList<>(){};


public static void baralhar()
{
    Random numero1 =new Random();
    int numero =numero1.nextInt(0,53);
    List<Integer> numeros=new ArrayList<>(){};
    int numeroDeCartas =0;


    numeros.add(numero);

    do {
        int j=0;
        Random a = new Random();
        int random = a.nextInt(0,52);
        for(int item : numeros) {

            if (random == item)
            {
                j++;
               break;
            }

        };

        if(j==0)
        {
            numeros.add(random);
            numeroDeCartas++;
        }



    }while (numeroDeCartas<51);

    IO.println(numeros);
    IO.readln();

}
    public Cards() {

        baralho = new  ArrayList<Cards>();
    }
}