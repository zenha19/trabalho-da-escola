import java.util.ArrayList;
import java.util.List;


public class Cards {

List<Cards> baralho =new ArrayList<>(){};

public static void baralhar()
{

}


}
