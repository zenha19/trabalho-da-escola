import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class Cards {


    static List<Baralho> baralho =new ArrayList<>(){};


public static void baralhar()
{
    Random numero1 =new Random();
    int numero =numero1.nextInt(0,52);
    List<Integer> numeros=new ArrayList<>(){};
    int numeroDeCartas =0;


    numeros.add(numero);

    do {
        int j=0;
        Random a = new Random();
        int random = a.nextInt(0,52);
        for(int item : numeros) {

            if (random == item)
            {
                j++;
               break;
            }

        };

        if(j==0)
        {
            numeros.add(random);
            numeroDeCartas++;
        }



    }while (numeroDeCartas<51);
numeroDeCartas=0;
int indexnumber=0;
int indexbaralho=0;
    do
    {

        if(numeros.get(indexnumber) ==Baralho.cardslist.get(indexbaralho).id)
        {
            Cards.baralho.add(Baralho.cardslist.get(indexbaralho));
            numeroDeCartas++;
            indexnumber++;
            indexbaralho=0;
        }
        else
        {
            indexbaralho++;
        }


    }while (numeroDeCartas <52);


}
    public Cards() {

        baralho = new ArrayList<>();
    }
}